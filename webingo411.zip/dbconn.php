<?php
/* Database connection settings */
$conn = mysqli_connect("localhost", "webingo_user", "PQosfwOEC{}I", "webingo_admin");
//$conn = mysqli_connect("localhost", "root", "", "webingo_db");
//$con = mysqli_connect("webcloud1", "webingoi_prouser", "Pr199813@", "webinogoi_shyammandir");
// Check connection
//if ($mysqli->error) {Dqs%qV~7nf+j
  //  die("Connection failed: " . $mysqli->error);
//}
//echo "Connected successfully";
?>