<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>

		<?php include 'meta.php'; ?>
		
		<!--plugin-css-->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/plugin.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
		<!-- template-style-->
		<link href="css/style.css" rel="stylesheet">
		<link href="css/responsive.css" rel="stylesheet">
		<link href="css/sideform.css" rel="stylesheet">
		<link href="css/breadcum-form.css" rel="stylesheet">
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=UA-164733026-1"></script>
		<script>
		  window.dataLayer = window.dataLayer || [];
		  function gtag(){dataLayer.push(arguments);}
		  gtag('js', new Date());

		  gtag('config', 'UA-164733026-1');
		</script>
	  <style>
		  @media (min-width: 320px) and (max-width: 765px){
   .hide {
         display:none;
	 }
			  
}
		  	  @media (min-width: 320px) and (max-width: 765px){
   .lm {
         margin-left: 0px;
	 }
			  
}
		  @media screen and (min-width: 1370px){
				.hero-card-web1 {
					position: relative;
					overflow: hidden;
					padding-top: 82px;
					padding-bottom: 72px;
					height: 65vh;
					align-items: center;
					display: flex;
					margin-left: -150px
				}
				.headerclient {
					padding-top: 14px;
					padding-bottom: 0px;
				}
				.computer{
					margin-left: -240px;
				}
			}
			@media screen and (max-width: 1370px){
				.image-sr-mm1{
					width: 100%;
					height: 130px;
					padding-top: 7px;
				}
				.pb1{
					padding-top: 7px;
				}
				.computer{
					margin-left: -120px;
				}
			}
	  </style>
  </head>
  <body>
       		<!--Start Header -->
		  
		  <?php include 'header.php'; ?>
<!--End Header -->

	     <!--Breadcrumb Area-->
  <!--Start Hero-->
<section class="hero-card-web hero-card-web1 hero-card-web2  bg-gradient12 shape-bg3">
<div class="hero-main-rp container-fluid">
<div class="row">
<div class="col-lg-4">
<div class="single-image wow fadeIn" style="visibility: visible; animation-name: fadeIn;margin-top:10%" >
<img src="images/image2/psd_bredcrumb.png" alt="image" class="img-fluid no-shadow">
</div>
</div>
<div class="col-lg-4 col-12 " style="margin-top: 4%">
	<div class="service-sec-list " style="text-align:center">
		<img src="images/icons/tech.svg" alt="service" >
		<h5 class="mb10" style="color: white">WebInGo at It's Best</h5>
		<div class="row in-stats  about-statistics">
            <div class="col-lg-4 col-sm-4" style="padding-left:0;padding-right:0;border-right: 1px solid white;">
              <div class="statistics">
                <div class="statnumb counter-number">
                  <span class="counter">4</span><span>+</span>
                  <span style="font-weight:900;font-size:11px;">Years Experience</span>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-sm-4" style="padding-left:0;padding-right:0;border-right: 1px solid white;">
              <div class="statistics">
                <div class="statnumb">
                  <span class="counter">10</span><span>+</span>
                  <span style="font-weight:900;font-size:11px;">Org Recogination</span>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-sm-4">
              <div class="statistics mb0">
                <div class="statnumb counter-number">
                  <span class="counter">500</span><span>+</span>
                  <span style="font-weight:900;font-size:11px;">Happy Clients</span>
                </div>
              </div>
            </div>
          </div>
		<p style="color: white;text-align: justify">WEBINGO® is a renowned end-to-end IT solutions company in India that provides ultimate IT solutions and has provided consultancy to numerous start-ups across India.  </p>
 </div>   
</div>
<div class="col-lg-4" >
<div class="hero-content-sec wow fadeIn" data-wow-delay="0.8s">
<form method="post" style="margin-top: -23px;">
	<h5 class="mb10" style="text-align:center">Get Free Quotation</h5>
  <input 
    name="Your Name"
    placeholder="Name"
    required
  >
  <input 
    type="email"
    name="email" 
    placeholder="Email"
    required
  >
  <input
    type="mobile"
    name="mobile" 
    placeholder="Phone No"
  >
	<input
    type="text"
    name="city" 
    placeholder="Your City"
  >
 <select   name="interest" id="interest">
	<option value="" class="grey_color">Interested In*</option>
	<option value="Logo Design">Logo Design</option>
	<option value="Packaging Design">Packaging Design</option>
	<option value="Website Design">Website Design</option>
	<option value="Responsive / Bootstrap HTML">Responsive / Bootstrap HTML</option>
	<option value="Website Development">Website Development</option>
	<option value="Wordpress">Wordpress</option>
	<option value="Magento">Magento</option>
	<option value="SEO &amp; SMO">SEO &amp; SMO</option>
	<option value="Hosting">Hosting</option>
	<option value="ECommerce Website">ECommerce Website</option>
	<option value="Digital Marketing">Digital Marketing</option>
	<option value="Graphics Design">Graphics Design</option>
	<option value="Brochure, Business Card, Flyer Design">Brochure, Business Card, Flyer Design</option>
<option value="Content Writing Services">Content Writing Services</option>
		      			</select>
 <br>
	<div class="col-md-12"> 				
		<input type="hidden" value="" name="secret"   id="secret"/>
		<input class="btn btn-primary bg-btn2" type="button" value="Submit" name="Submit"   id="Submit" onclick="contactquick();"/>
	</div> 
</form>
</div>
</div>
</div>
</div>
</section>
  <!--End Breadcrumb Area-->
  <!--End Breadcrumb-->  
	   <section class="service pad-tb about-agency light-dark">
<div class="container">
<div class="row">
	 <div class="col-lg-12 text-center"><h2 class="mb20" style=""><div class="quotes">
    <blockquote>
      <p>We don't just build websites; we build websites that SELLS.</p>
      <footer>
      </footer>
    </blockquote>
  </div></h2></div>
<div class="col-lg-7" style="margin-top:4%">
<div class="text-l service-desc- pr25">
	<span  class="text-radius text-light text-animation bg-b">GROW TRAFFIC &amp; INCREASE REVENUE</span>
	<h2>  Let us give you some insight about PSD to WordPress Development</h2>
	<br>
<p style="text-align: justify">No matter how complex your requirements are, whether you are developing a simple, dynamic or a complex eCommerce website, PSD to WP Convert in a meaningful way. Whether you want to convert PSD to WordPress responsive, custom WordPress development services or it is about WordPress theme integration to your website, we custom-code backend of WordPress to make your WordPress theme conversion fruitful. Our team delivers even complicated projects well within the defined timeline and will always ready to assist you anytime, anywhere! Further to add, we never hesitate to face criticism and consider the changes to re-iterate the conversion approach. Count on us for professional Responsive WP Theme Development and conversion services as we offer custom WordPress theme/template customization and conversions in a budget-friendly way. With our variety of engagement models, we provide plenty of options to our partners and clients to get in touch with us and engage with us profitably.</p>
<a href="#" class="btn-main bg-btn2 lnk mt30">Request A Quote  <i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
</div>
</div>
<div class="col-lg-5">
<div class="single-image wow fadeIn" style="visibility: visible; animation-name: fadeIn; 
  box-shadow: 10px 10px 5px #aaaaaa;">
<img src="images/image2/psd-wp1.png" alt="image" class="img-fluid no-shadow" style="
  box-shadow: 10px 10px 5px #aaaaaa;">
</div>
</div>
</div>
</div>
</section>

	  <section class="service pad-tb bg-gradient15 light-dark">
<div class="container">
<div class="row">
	<div class="col-lg-1"></div>
<div class="col-lg-5">
<div class="single-image wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
<img src="images/image2/psd_2.png" alt="image" class="img-fluid no-shadow">
</div>
</div>
	<div class="col-lg-1"></div>
<div class="col-lg-5">
<div class="servie-key-points">
  <h4>Benefits of PSD to WordPress Development   </h4>
  <ul class="key-points mt20">
      <li>Pixel-Perfect Design.</li>
      <li>Enhanced Usability.</li>
      <li>In-Built Blogging System.</li>
      <li>Responsive Design.</li>
      <li>SEO Friendly Website.</li>
	  <li>Easy and Cost-effective Solutions.</li>
	  <li>eCommerce Integration.</li>
  </ul>
</div>
</div>
</div>
</div>
</section>

<section class="service-section pad-tb">
<div class="container">
<div class="row justify-content-center">
<div class="col-lg-8">
<div class="common-heading">
<span class="text-light text-animation bg-b">Services We Provided</span>
<h2 class="mb30" style="color:#000;">What we offer?</h2>
</div>
</div>
</div>
<div class="row upset link-hover shape-num justify-content-center">
<div class="col-lg-4 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
<div class="s-block" data-tilt="" data-tilt-max="5" data-tilt-speed="1000" style="will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
<div class="s-card-icon"><img src="images/icons/branding.svg" alt="service" class="img-fluid"></div>
<p style="color:#000;">Responsive WP Theme Development.</p>
<!--<a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>-->
</div>
</div>
<div class="col-lg-4 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
<div class="s-block" data-tilt="" data-tilt-max="5" data-tilt-speed="1000" style="will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
<div class="s-card-icon"><img src="images/icons/development.svg" alt="service" class="img-fluid"></div>
<p style="color:#000;">Template Conversion.</p>
<!--<a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>-->
</div>
</div>
<div class="col-lg-4 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
<div class="s-block" data-tilt="" data-tilt-max="5" data-tilt-speed="1000" style="will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
<div class="s-card-icon"><img src="images/icons/app.svg" alt="service" class="img-fluid"></div>
<p style="color:#000;">HTML to WordPress Conversion.</p>
<!--<a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>-->
</div>
</div> 
<div class="col-lg-4 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
<div class="s-block" data-tilt="" data-tilt-max="5" data-tilt-speed="1000" style="will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
<div class="s-card-icon"><img src="images/icons/app.svg" alt="service" class="img-fluid"></div>
<p style="color:#000;">WordPress Slicing.</p>
<!--<a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>-->
</div>
</div> 
<div class="col-lg-4 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
<div class="s-block" data-tilt="" data-tilt-max="5" data-tilt-speed="1000" style="will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
<div class="s-card-icon"><img src="images/icons/app.svg" alt="service" class="img-fluid"></div>
<p style="color:#000;">WordPress Customization.</p>
<!--<a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>-->
</div>
</div> 
<div class="col-lg-4 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;">
<div class="s-block mb0" data-tilt="" data-tilt-max="5" data-tilt-speed="1000" style="will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
<div class="s-card-icon"><img src="images/icons/marketing.svg" alt="service" class="img-fluid"></div>
<p style="color:#000;">WordPress Theme Integration.</p>
<!--<a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>-->
</div>
</div>
</div>
<div class="-cta-btn mt70">
<div class="free-cta-title v-center wow zoomInDown" data-wow-delay=".9s" style="visibility: visible; animation-delay: 0.9s; animation-name: zoomInDown;">
<p>Hire a <span>Dedicated Developer</span></p>
<a href="#" class="btn-main bg-btn2 lnk">Hire Now<i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
</div>
</div>
</div>
</section>

	  <section class="service-block pad-tb bg-gradient8">
					<div class="container">
						<div class="row justify-content-center">
							<div class="col-lg-8">
								<div class="common-heading ptag">
									<span class="text-radius text-light text-animation bg-b">We Deliver Our Best</span>
									<h2>Why Choose WEBINGO?</h2>
									<p class="mb30" style="color: #fff;">We are the best at what we do.</p>
								</div>
							</div>
						</div>
						<div class="row justify-content-center">
							<div class="col-lg-4 col-sm-6 mt30  wow fadeIn" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"></div>
									<div class="s-block-content">
										<h4><img src="images/png/trustworthy.png" alt="service" class="img-fluids" style="max-width:32px;"> &nbsp;  Well – Commented Mark-ups </h4>
										
										<p style="text-align:justify;">
											Our PSD to WordPress development process ensures that all our markups are 100% hand-coded and commented properly in order to help you make the changes easy in future!</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"> </div>
									<div class="s-block-content">
										<h4><img src="images/png/dedicate-manager.png" alt="service" class="img-fluids" style="max-width:32px;"> &nbsp; Dedicated Coders </h4>
										<p style="text-align:justify;">
											Based on the engagement model selected, we will ensure that dedicated team of coders will work for your PSD to WordPress theme conversion while maintaining constant communication to check on work.</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay=".8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"></div>
									<div class="s-block-content">
										<h4><img src="images/png/technical.png" alt="service" class="img-fluids" style="max-width:32px;"> &nbsp; Browser Compatibility</h4>
										<p style="text-align:justify;">With our PSD to WordPress conversion services, you can assure that your website will be supporting all the latest and most popular browsers, including Internet Explorer, Google Chrome, Mozilla Firefox, Safari, Opera and more.</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay="1.1s" style="visibility: visible; animation-delay: 1.1s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"></div>
									<div class="s-block-content">
										<h4><img src="images/png/customer-service.png" alt="service" class="img-fluids" style="max-width:32px;"> &nbsp; Pixel-Perfect Clarity</h4>
										<p style="text-align:justify;">Our team of coders ensures that converted WordPress theme or templates are pixel-perfect across multiple browsers and devices irrespective of the aspect ratio to give end-users smooth and professional feel about your website.</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay="1.4s" style="visibility: visible; animation-delay: 1.4s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"></div>
									<div class="s-block-content">
										<h4><img src="images/png/timely.png" alt="service" class="img-fluids" style="max-width:32px;"> &nbsp; Search Engine Compatible</h4>
										<p style="text-align:justify;">With proven technical expertise and precision, we ensure that codes, images, CSS, and other back-end aspects are taken care well to avoid any technical glitches that may affect ranking of your website in search engines. Process of SEO will be trouble free.</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay="1.7s" style="visibility: visible; animation-delay: 1.7s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"></div>
									<div class="s-block-content">
										<h4><img src="images/png/punctuality.png" alt="service" class="img-fluids" style="max-width:32px;"> &nbsp; W3C Compatible</h4>
										<p style="text-align:justify;">The HTML and CSS code we use to build your website is fully compliant with the standards set by the World Wide Web consortium. We always use W3C validator tool in order to check the compliance and to avoid any errors that might cause any impact to your website.</p>
									</div>
								</div>
							</div>
						</div>
						<div class="-cta-btn mt70">
							<div class="free-cta-title v-center wow zoomInDown" data-wow-delay="1.8s" style="visibility: visible; animation-delay: 1.8s; animation-name: zoomInDown;">
								<p style="color: #fff">Let us <span>Serve you
									</span> </p>
								<a href="#" class="btn-main bg-btn2 lnk" data-toggle="modal" data-target="#myModal">Enquiry Now<i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
							</div>
						</div>
					</div>
				</section>
	  
		
	  <section class="pad-tb bg-gradient15" >
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <div class="common-heading">
	<span  class="text-radius text-light text-animation bg-b">FAQS</span>
            <h2 class="mb0">Frequently Asked Questions</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 mt60">
          <div id="accordion" class="accordion">
            <div class="card-1">
              <div class="card-header" id="faq1" style="background: linear-gradient(135deg,#3F74A3,#0000AA 32%,#4D4DFF);">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-a" aria-expanded="true" aria-controls="collapse-a"style="color: #fff;" >
				Time taken for PSD to HTML WordPress Conversion?
                </button>
              </div>
              <div id="collapse-a" class="card-body collapse " aria-labelledby="faq1" data-parent="#accordion">
                <p>
					As a general rule of thumb, it takes approximately one working day to convert one
					design to HTML5 &amp; CSS3 code, however this will depend on the complexity of the
					design.
					You will see an approximate delivery date during the quote process – after you
					submit your order, we will review your requirements before starting and will contact
					you if we have any questions or find anything that may delay delivery. At this point
					we will lock down a specific delivery date. If you are in a rush to have a specific
					project delivered within a short time frame, let us know. We can assign priority to you
					project, however this will require additional developers and as such will incur an
					additional charge.</p>
              </div>
            </div>
           <div class="card-1 ">
              <div class="card-header" id="faq5" style="background: linear-gradient(135deg,#3F74A3,#0000AA 32%,#4D4DFF);">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-e" aria-expanded="true" aria-controls="collapse-e"style="color: #fff;" >
              Which browsers do you support?
                </button>
              </div>
              <div id="collapse-e" class="card-body collapse" aria-labelledby="faq5" data-parent="#accordion2">
                <p>
					All of our sites are fully compatible with: Firefox 4+, Safari 4+, Opera, Google
					Chrome, Internet Explorer 9+ and iOS browsers. If you specifically require support
					for IE8, please let us know.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 mt60">
          <div id="accordion2" class="accordion">
			  <div class="card-1 ">
              <div class="card-header" id="faq4" style="background: linear-gradient(135deg,#3F74A3,#0000AA 32%,#4D4DFF);">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-b" aria-expanded="true" aria-controls="collapse-b"style="color: #fff;" >
                Do you provide support?
                </button>
              </div>
              <div id="collapse-b" class="card-body collapse" aria-labelledby="faq4" data-parent="#accordion2">
                <p>
					Yes, we give you 30 days free support with each project. After the 30 days, you can
					still of our support on a paid basis. Please note that revisions (i.e. changes to your
					initial design) are not covered by support. For this reason, we would encourage you
					to only place orders for approved designs.</p>
              </div>
            </div>
            <div class="card-1 ">
              <div class="card-header" id="faq2" style="background: linear-gradient(135deg,#3F74A3,#0000AA 32%,#4D4DFF);">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-f" aria-expanded="true" aria-controls="collapse-f"style="color: #fff;" >
                How do you handle revisions?
                </button>
              </div>
              <div id="collapse-f" class="card-body collapse" aria-labelledby="faq2" data-parent="#accordion2">
                <p>
					We are happy to make minor revisions free of charge (before delivery of source
					code). Any large revisions, which are not part of your original design, will need to be
					quoted separately. Our recommendation: To avoid any surprises here, we would
					encourage you to include only approved designs in your order.
					If you require any changes after we have delivered the source code, simply contact
					our support desk and we will be more than happy to quote you for the changes.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<!--Start Footer-->
 <?php include 'footer.php'; ?>
<!--End Footer-->
<!--scroll to top-->
<a id="scrollUp" href="#top"></a>
<!-- js placed at the end of the document so the pages load faster -->
<script src="js/vendor/modernizr-3.5.0.min.js"></script>
<script src="js/jquery.min.js"></script>x
<script src="js/bootstrap.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/plugin.min.js"></script>
<!--common script file-->
<script src="js/main.js"></script>
		  <script>
		  $('.bxslider').bxSlider({
  autoHover: true,
  auto: true,
  slideWidth: 250,
  minSlides: 2,
  maxSlides: 6,
  controls: true,
  pager: true,
  speed: 500,
  captions: true,
  slideMargin: 5,
});
		  </script>	  
<script>
$(document).foundation();

// declare variables.
var $top_bar = $('.top-bar'),
    $menu_btn = $('#responsive-menu-btn');

// top bar sticky shrink class toggle.
$top_bar.on('sticky.zf.stuckto:top', function() {
  var $this = $(this);
  
  $this.addClass('shrink');
}).on('sticky.zf.unstuckfrom:top', function() {
  var $this = $(this);
  
  $this.removeClass('shrink');
})

// top bar responsive menu button context toggle.
$menu_btn.on('click', function(){
  $this = $(this);
  
  $this.toggleClass('alert').promise().done(function()
  {
    if ($this.hasClass('alert')) {
      $this.html('<i class="fa fa-md fa-times"></i> Close');
    } else {
      $this.html('<i class="fa fa-md fa-bars"></i> Menu');
    }
  });
});		  
</script>
<script>
grecaptcha.ready(function() {
    grecaptcha.execute('6Lf4wNEZAAAAACeNgAtPhbDG2MuNRHf5HYwGBOcF', {action: 'submit'}).then(function(token) {
    console.log(token);
       document.getElementById("g-token").value = token;
    });
});
</script>
</body>
</html>