<?php

include 'dbconn.php';
                                      $sl = '1';
                                          $sql = mysqli_query($conn, "SELECT * FROM metatags ORDER BY id ASC");
                                          while($row = mysqli_fetch_array($sql))
                                          {
                                          	echo $row['content'];
                                          }
                                          ?>

<meta charset="utf-8"/>
		<meta name="viewport" content="width=device-width,initial-scale=1">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="theme-color" content="#322d97">
   <title>Webingo | Best Web development company in Kolkata India</title>  
<meta name="description" content= "Best graphic designing, web development, app development and digital marketing solution in Kolkata India" />
<meta name="robots" content= "index, follow">
    <meta name="keywords" content="Best graphic designing, web development, app development and digital marketing solution">

		<meta property="og:image" content="https://webingo.in/images/white-logo.png" />
		<meta property="fb:app_id" content="666956320614810" />
		<meta property="og:url" content="https://webingo.in/index.php" />
		<meta property="og:title" content="Webingo | Best Web development company in Kolkata India" />

<meta name="author" content="Webingo">
    <!--website-favicon-->
    <link href="images/favicon.png" rel="icon">

<link rel="stylesheet" href="https://s3.amazonaws.com/smatbot/files/smatbot.css.gz">
<script type="text/javascript">var otherPulseDiv=document.createElement("DIV");otherPulseDiv.id="pulse_smatbot_unique";var mainDiv=document.createElement("DIV");otherPulseDiv.appendChild(mainDiv);mainDiv.id="closed";var img=document.createElement("Img");img.id="main_icon_smatest";img.src="https://s3.ap-south-1.amazonaws.com/custpostimages/sb_images/chat-loading.gif";var imgLogo=document.createElement("Img");imgLogo.id="logo-smatest";imgLogo.classList.add("logo-smatest");mainDiv.appendChild(img);mainDiv.classList.add("pointer");mainDiv.classList.add("smat-div-before");img.classList.add("smat-main-btn-before");otherPulseDiv.classList.add("pulse-div-before");document.addEventListener("DOMContentLoaded",function(event){document.body.appendChild(otherPulseDiv)});</script>
<script type="text/javascript">!function(t,e){"use strict";var r=function(t){try{var r=e.head||e.getElementsByTagName("head")[0],a=e.createElement("script"),b=document.getElementsByTagName("script")[0];a.setAttribute("type","text/javascript"),a.setAttribute("src",t),a.async=!0,r.insertBefore(a,b)}catch(t){}};t.chatbot_id=5025,r("https://s3.amazonaws.com/smatbot/files/smatbot_plugin.js.gz")}(window,document);</script><script src="https://cdnjs.cloudflare.com/ajax/libs/fingerprintjs2/1.5.1/fingerprint2.min.js"></script>