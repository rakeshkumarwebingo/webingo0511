<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>

		<?php include 'meta.php'; ?>
		
		<!--plugin-css-->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/plugin.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
		<!-- template-style-->
		<link href="css/style.css" rel="stylesheet">
		<link href="css/responsive.css" rel="stylesheet">
		<link href="css/sideform.css" rel="stylesheet">
		<link href="css/breadcum-form.css" rel="stylesheet">
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=UA-164733026-1"></script>
		<script>
		  window.dataLayer = window.dataLayer || [];
		  function gtag(){dataLayer.push(arguments);}
		  gtag('js', new Date());

		  gtag('config', 'UA-164733026-1');
		</script>
	  <style>
		  @media (min-width: 320px) and (max-width: 765px){
   .hide {
         display:none;
	 }
			  
}
		  	  @media (min-width: 320px) and (max-width: 765px){
   .lm {
         margin-left: 0px;
	 }
			  
}
		  @media screen and (min-width: 1370px){
				.hero-card-web1 {
					position: relative;
					overflow: hidden;
					padding-top: 82px;
					padding-bottom: 72px;
					height: 65vh;
					align-items: center;
					display: flex;
					margin-left: -150px
				}
				.headerclient {
					padding-top: 14px;
					padding-bottom: 0px;
				}
				.computer{
					margin-left: -240px;
				}
			}
			@media screen and (max-width: 1370px){
				.image-sr-mm1{
					width: 100%;
					height: 130px;
					padding-top: 7px;
				}
				.pb1{
					padding-top: 7px;
				}
				.computer{
					margin-left: -120px;
				}
			}
	  </style>
  </head>
  <body>
<!--Start Header -->
		  <?php include 'header.php'; ?>
<!--End Header -->
  <!--Start Hero-->
<section class="hero-card-web hero-card-web1 hero-card-web2  bg-gradient12 shape-bg3">
<div class="hero-main-rp container-fluid">
<div class="row">
<div class="col-lg-4">
<div class="single-image wow fadeIn" style="visibility: visible; animation-name: fadeIn;margin-top:10%" >
<img src="images/image2/responsive_bred.png" alt="image" class="img-fluid no-shadow">
</div>
</div>
<div class="col-lg-4 col-12 " style="margin-top: 4%">
	<div class="service-sec-list " style="text-align:center">
		<img src="images/icons/tech.svg" alt="service" >
		<h5 class="mb10" style="color: white">WebInGo at It's Best</h5>
		<div class="row in-stats  about-statistics">
            <div class="col-lg-4 col-sm-4" style="padding-left:0;padding-right:0;border-right: 1px solid white;">
              <div class="statistics">
                <div class="statnumb counter-number">
                  <span class="counter">4</span><span>+</span>
                  <span style="font-weight:900;font-size:11px;">Years Experience</span>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-sm-4" style="padding-left:0;padding-right:0;border-right: 1px solid white;">
              <div class="statistics">
                <div class="statnumb">
                  <span class="counter">10</span><span>+</span>
                  <span style="font-weight:900;font-size:11px;">Org Recogination</span>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-sm-4">
              <div class="statistics mb0">
                <div class="statnumb counter-number">
                  <span class="counter">500</span><span>+</span>
                  <span style="font-weight:900;font-size:11px;">Happy Clients</span>
                </div>
              </div>
            </div>
          </div>
		<p style="color: white;text-align: justify">WEBINGO® is a renowned end-to-end IT solutions company in India that provides ultimate IT solutions and has provided consultancy to numerous start-ups across India.  </p>
 </div>   
</div>
<div class="col-lg-4" >
<div class="hero-content-sec wow fadeIn" data-wow-delay="0.8s">
<form method="post" style="margin-top: -23px;">
	<h5 class="mb10" style="text-align:center">Get Free Quotation</h5>
  <input 
    name="Your Name"
    placeholder="Name"
    required
  >
  <input 
    type="email"
    name="email" 
    placeholder="Email"
    required
  >
  <input
    type="mobile"
    name="mobile" 
    placeholder="Phone No"
  >
	<input
    type="text"
    name="city" 
    placeholder="Your City"
  >
 <select   name="interest" id="interest">
	<option value="" class="grey_color">Interested In*</option>
	<option value="Logo Design">Logo Design</option>
	<option value="Packaging Design">Packaging Design</option>
	<option value="Website Design">Website Design</option>
	<option value="Responsive / Bootstrap HTML">Responsive / Bootstrap HTML</option>
	<option value="Website Development">Website Development</option>
	<option value="Wordpress">Wordpress</option>
	<option value="Magento">Magento</option>
	<option value="SEO &amp; SMO">SEO &amp; SMO</option>
	<option value="Hosting">Hosting</option>
	<option value="ECommerce Website">ECommerce Website</option>
	<option value="Digital Marketing">Digital Marketing</option>
	<option value="Graphics Design">Graphics Design</option>
	<option value="Brochure, Business Card, Flyer Design">Brochure, Business Card, Flyer Design</option>
<option value="Content Writing Services">Content Writing Services</option>
		      			</select>
 <br>
	<div class="col-md-12"> 				
		<input type="hidden" value="" name="secret"   id="secret"/>
		<input class="btn btn-primary bg-btn2" type="button" value="Submit" name="Submit"   id="Submit" onclick="contactquick();"/>
	</div> 
</form>
</div>
</div>
</div>
</div>
</section>
  <!--End Breadcrumb Area-->
  <!--End Breadcrumb-->  
	   <section class="service pad-tb about-agency light-dark">
<div class="container">
<div class="row">
	 <div class="col-lg-12 text-center"><h2 class="mb20" style=""><div class="quotes">
    <blockquote>
      <p>What separates design from art is that design is meant to be... <br>functional</p>
      <footer>
      </footer>
    </blockquote>
  </div></h2></div>
<div class="col-lg-7" style="margin-top:4%">
<div class="text-l service-desc- pr25">
	<span  class="text-radius text-light text-animation bg-b">GROW TRAFFIC &amp; INCREASE REVENUE</span>
	<h2>  About Responsive Web Design</h2>
	<br>
	<p style="text-align: justify">Initially, people used to browse the web only on their PC's or Laptop's. With the fast development in fields of technology and infrastructure, today people surf while on the go, on their Tablet's and Mobiles. Due to this having a Responsive Website becomes all the more important, as the word says responsive. The best part of such websites is that it adjusts to the screen resolution of the device you have opened the website on.<br>
A responsive website can anytime give a better browsing experience to a user and are also recommended for Search Engine Optimization. Responsive web design services are new age Internet concepts which have unleashed a new era of web-surfing altogether! These new websites ensure a distinctly better surfing experience, and grab complete attention of your target viewer. In fact, search engine like Google prefers to rank responsive website higher on their search result pages, because a responsive website will be easy to browse for its users.<br>
Over the years, Google has always tried to prefer sites which are informative and user friendly. Due to this important factor, it becomes all the more necessary to have a SEO friendly responsive website for your business.</p>
<a href="#" class="btn-main bg-btn2 lnk mt30">Request A Quote  <i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
</div>
</div>
<div class="col-lg-5" style="margin-top:4%">
<div class="single-image wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
<img src="images/image2/responsive.png" alt="image" class="img-fluid no-shadow">
</div>
</div>
</div>
</div>
</section>

<section class="service pad-tb bg-gradient15 light-dark">
<div class="container">
<div class="row">
<div class="col-lg-7">
<div class="text-l service-desc- pr25">
  <h3 class="mb20" style="color:#000">What We Do? </h3>  
	<p style="text-align: justify">Over the years, Google has always tried to prefer sites which are informative and user friendly. Due to this important factor, it becomes all the more necessary to have a SEO friendly responsive website for your business.<br>
As an IT solutions company from Kolkata we ensure both a holistic visual experience for the end user; as well as technically perfect websites - successfully giving you the upper edge in the vast virtual market space. For us, responsive web design services are about ensuring 100% viewer satisfaction and the browsing. Our team can also help you to optimize your responsive website and thereby get you maximum visitors who may be using various devices and browsers.<br>
</p>
  <a href="#" class="btn-main bg-btn2 lnk mt30">Get a package  <i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
</div>
</div>
<div class="col-lg-5">
<div class="servie-key-points">
  <h4>What We Offer?  </h4>
  <ul class="key-points mt20">
      <li>eCommerce Development Service.</li>
      <li>Responsive Website Designing Service.</li>
      <li>Responsive Blogs Design Service.</li>
      <li>Responsive Forum Design Service.</li>
      <li>Responsive Web Development.</li>
	  <li>Responsive Web App Development.</li>
	  <li>Responsive web page redesign</li>
  </ul>
</div>
</div>
</div>
</div>
</section>
	  
				<section class="why-choos-lg pad-tb about-agency light-dark">
				<div class="container">
					<div class="row justify-content-center">
					<div class="col-lg-8">
						<div class="common-heading ptag">
							<span class="text-radius text-light text-animation bg-b">We Deliver Our Best</span>
							<h2>Our Assurance</h2>
							<p class="mb30">Our Assurance that the following will be provided/ followed.</p>
						</div>
					</div>
				</div>
				<div class="row">
				<div class="col-lg-6">
				<div class="common-heading text-l">
				<div class="itm-media-object mt40">
					<div class="media">
						<img src="images/icons/navigation.png" alt="icon">
						<div class="media-body">
							<h4>Fluid Navigation</h4>
							<p style="text-align:justify;">
							Smooth navigation throughout the site to make it user friendly</p>
						</div>
					</div>
					<div class="media mt40">
						<img src="images/icons/scrolling.png" alt="icon">
						<div class="media-body">
							<h4> Zero Scrolling</h4>
							<p style="text-align:justify;">
							No annoying horizontal scrolling for any resolution or screen size.</p>
						</div>
					</div>
					<div class="media mt40">
						<img src="images/icons/solution.png" alt="icon">
						<div class="media-body">
							<h4>Logically Planned Layout</h4>
							<p style="text-align:justify;">
							A layout that is based on the study of user experience and user interaction.</p>
						</div>
					</div>
				</div>
				</div>
				</div>
				<div class="col-lg-6">
				<div class="itm-media-object mt40">
					<div class="media">
						<img src="images/icons/quality-2.png" alt="icon">
						<div class="media-body">
							<h4> W3c Credibility</h4>
							<p style="text-align:justify;">
				Focus on keeping elements and codes completely W3C validated.</p>
						</div>
					</div>
					<div class="media mt40">
						<img src="images/icons/diagram.png" alt="icon">
						<div class="media-body">
							<h4>Proper Call-to-Action</h4>
							<p style="text-align:justify;">
				A pre-planned architecture to make visitors flow in your desired action.</p>
						</div>
					</div>
					<div class="media mt40">
						<img src="images/icons/remember-1.png" alt="icon">
						<div class="media-body">
							<h4>Highly Affordable</h4>
							<p style="text-align:justify;">
							Great quality services and results with highly competitive prices.</p>
						</div>
					</div>
				</div>
				</div>
				</div>
				</div>
				</section>
	  
	  <section class="service-block pad-tb bg-gradient8">
					<div class="container">
						<div class="row justify-content-center">
							<div class="col-lg-8">
								<div class="common-heading ptag">
									<span class="text-radius text-light text-animation bg-b">We Deliver Our Best</span>
									<h2>Why Choose WEBINGO?</h2>
									<p class="mb30" style="color: #fff">We are the best at what we do.</p>
								</div>
							</div>
						</div>
						<div class="row justify-content-center">
							<div class="col-lg-6 col-sm-6 mt30  wow fadeIn" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"><img src="images/png/trustworthy.png" alt="service" class="img-fluids"></div>
									<div class="s-block-content">
										<h4>Qualified Web Designers</h4>
										
										<p style="text-align:justify;">
											We have highly skilled and talented web designers who use a range of creative and technical skills to build websites that are visually attractive and technically sound. Our designers have experience in creating websites in a range of formats for a wide variety of industries.</p>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-sm-6 mt30 wow fadeIn" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"><img src="images/icons/remember.png" alt="service" class="img-fluids"></div>
									<div class="s-block-content">
										<h4>Latest Technologies</h4>
										<p style="text-align:justify;">
											Standards in web design sometimes change faster than they can be implemented. To stay one step ahead, we focus on trends, techniques, and latest technologies such as AI, blockchain, AR/VR and more to provide our clients with the most advanced designing solutions.</p>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-sm-6 mt30 wow fadeIn" data-wow-delay=".8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"><img src="images/icons/meeting.png" alt="service" class="img-fluids"></div>
									<div class="s-block-content">
										<h4>User-Centric Approach</h4>
										<p style="text-align:justify;">
											We do a robust research on our client’s users and make decisions based on how they think and what they want. User preferences is an integral part of our web design process. As the best website designing company in India, we know what it takes to provide real human experiences.</p>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-sm-6 mt30 wow fadeIn" data-wow-delay=".8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeIn;">
								<div class="s-block wide-sblock">
									<div class="s-card-icon"><img src="images/icons/quality-1.png" alt="service" class="img-fluids"></div>
									<div class="s-block-content">
										<h4>Transparency and Quality</h4>
										<p style="text-align:justify;">
											
											Webingo is more than an award-winning responsive web design services provider. We believe in true partnership with you, transparency and delivering quality solutions to help your brand make deeper connections with your customers and accelerate growth.</p>
									</div>
								</div>
							</div>
						</div>
						<div class="-cta-btn mt70">
							<div class="free-cta-title v-center wow zoomInDown" data-wow-delay="1.8s" style="visibility: visible; animation-delay: 1.8s; animation-name: zoomInDown;">
								<p style="color: #fff">Let us <span>Serve you
									</span> </p>
								<a href="#" class="btn-main bg-btn2 lnk" data-toggle="modal" data-target="#myModal">Enquiry Now<i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
							</div>
						</div>
					</div>
				</section>

	<section class="pad-tb bg-gradient15" >
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <div class="common-heading">
			<span  class="text-radius text-light text-animation bg-b">FAQS</span>
            <h2 class="mb0">Frequently Asked Questions</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 mt60">
          <div id="accordion" class="accordion">
            <div class="card-1">
              <div class="card-header" id="faq1" style="background: linear-gradient(135deg,#3F74A3,#0000AA 32%,#4D4DFF);">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-a" aria-expanded="true" aria-controls="collapse-a"style="color: #fff;" >
				How long does it take to build a website?
                </button>
              </div>
              <div id="collapse-a" class="card-body collapse " aria-labelledby="faq1" data-parent="#accordion">
                <p>
					We have defined time of web designing packages for corporate websites & ecommerce websites as per the number of pages and features in the website - View Our Web Design Packages. Generally, business websites take 4 weeks to 6 weeks’ time for a website ranging from 10 products/services categories to 100 categories.<br>
					For customised website, every business comes with unique requirements and strategy. Without discussion, it's hard to guess and hence we can't answer the time to build a website. Through discussion with clients and planning, we will be able to understand your requirements and then we can tell the exact time for a project.</p>
              </div>
            </div>
           <div class="card-1 ">
              <div class="card-header" id="faq5" style="background: linear-gradient(135deg,#3F74A3,#0000AA 32%,#4D4DFF);">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-e" aria-expanded="true" aria-controls="collapse-e"style="color: #fff;" >
              Do you provide hosting services?
                </button>
              </div>
              <div id="collapse-e" class="card-body collapse" aria-labelledby="faq5" data-parent="#accordion2">
                <p>
					Yes, we provide web hosting services for all our websites, please get in touch for a free quote.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 mt60">
          <div id="accordion2" class="accordion">
			  <div class="card-1 ">
              <div class="card-header" id="faq4" style="background: linear-gradient(135deg,#3F74A3,#0000AA 32%,#4D4DFF);">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-b" aria-expanded="true" aria-controls="collapse-b"style="color: #fff;" >
                Can I get content writing service?
                </button>
              </div>
              <div id="collapse-b" class="card-body collapse" aria-labelledby="faq4" data-parent="#accordion2">
                <p>
					Definitely. We have in-house experienced copywriters. We can write SEO friendly & engaging content for your website.</p>
              </div>
            </div>
            <div class="card-1 ">
              <div class="card-header" id="faq2" style="background: linear-gradient(135deg,#3F74A3,#0000AA 32%,#4D4DFF);">
                <button class="btn btn-link btn-block text-left card-title collapsed" type="button" data-toggle="collapse" data-target="#collapse-f" aria-expanded="true" aria-controls="collapse-f"style="color: #fff;" >
                Can I get my existing website redesigned?
                </button>
              </div>
              <div id="collapse-f" class="card-body collapse" aria-labelledby="faq2" data-parent="#accordion2">
                <p>
					Yes, we can redesign your website if you want to enhance its look by making it modern. Get in touch with us and discuss your objective & goal with the new website.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<!--Start Footer-->
 <?php include 'footer.php'; ?>
<!--End Footer-->
<!--scroll to top-->
<a id="scrollUp" href="#top"></a>
<!-- js placed at the end of the document so the pages load faster -->
<script src="js/vendor/modernizr-3.5.0.min.js"></script>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/plugin.min.js"></script>
<!--common script file-->
<script src="js/main.js"></script>
		  <script>
		  $('.bxslider').bxSlider({
  autoHover: true,
  auto: true,
  slideWidth: 250,
  minSlides: 2,
  maxSlides: 6,
  controls: true,
  pager: true,
  speed: 500,
  captions: true,
  slideMargin: 5,
});
		  </script>	  
<script>
$(document).foundation();

// declare variables.
var $top_bar = $('.top-bar'),
    $menu_btn = $('#responsive-menu-btn');

// top bar sticky shrink class toggle.
$top_bar.on('sticky.zf.stuckto:top', function() {
  var $this = $(this);
  
  $this.addClass('shrink');
}).on('sticky.zf.unstuckfrom:top', function() {
  var $this = $(this);
  
  $this.removeClass('shrink');
})

// top bar responsive menu button context toggle.
$menu_btn.on('click', function(){
  $this = $(this);
  
  $this.toggleClass('alert').promise().done(function()
  {
    if ($this.hasClass('alert')) {
      $this.html('<i class="fa fa-md fa-times"></i> Close');
    } else {
      $this.html('<i class="fa fa-md fa-bars"></i> Menu');
    }
  });
});		  
</script>
<script>
grecaptcha.ready(function() {
    grecaptcha.execute('6Lf4wNEZAAAAACeNgAtPhbDG2MuNRHf5HYwGBOcF', {action: 'submit'}).then(function(token) {
    console.log(token);
       document.getElementById("g-token").value = token;
    });
});
</script>
</body>
</html>