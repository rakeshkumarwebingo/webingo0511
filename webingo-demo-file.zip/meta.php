<?php

include 'dbconn.php';
                                      $sl = '1';
                                          $sql = mysqli_query($conn, "SELECT * FROM metatags ORDER BY id ASC");
                                          while($row = mysqli_fetch_array($sql))
                                          {
                                          	echo $row['content'];
                                          }
                                          ?>
